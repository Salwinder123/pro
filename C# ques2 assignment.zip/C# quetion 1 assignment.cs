﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication21
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;

            Console.WriteLine("Student's age");
            String num = Console.ReadLine();
            double age = double.Parse(num);
            Console.WriteLine("International Student");
            string a = Console.ReadLine();
            Console.WriteLine("Registration Semester");
            string b = Console.ReadLine();
            if (a == "no")
            {
                if (age <= 18)
                { 
                x=300+(13/100*300);
                Console.WriteLine("Base Tuition" +x);
                }
                else if (age <= 49)
                {
                    x = 500 + (13 / 100 * 300);
                    Console.WriteLine("Base Tuition" + x);
                }
                else { 
                x=400+(13/100*400);
                Console.WriteLine("Base Tuition" +x);
                }
            }
                else if (a=="yes")
                {
                if(age<=18)
                {
                x=400+(13/100*400);
                    Console.WriteLine("Internation Student fee" +x);
                }
                else if(age<=49)
                {
                x=600+(13/100*600);
                    Console.WriteLine("International Student fee" +x);
                }
                else{
                x=500+(13/100*500);
                    Console.WriteLine("International Student fee" +x);
                }

                    switch(b)
            {
                case "fall":
                    {
                    y=250+(13/100*250);
                        Console.WriteLine("Registration fee for semester" +y);
                        break;
                    }
                case  "winter":
                    {
                    y=250+(13/300*220);
                        Console.WriteLine("Registration fee for semester" +y);
                        break;
                    }
                case "summer":
                    {
                    y=150+(13/300*150);
                        Console.WriteLine("Registration fee for semester" +y);
                        break;
                    }
                default:
                    {
                    Console.WriteLine("Enter valid month");
                        break;
                    }
            
            }
            }
        }
    }
}
