﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication22
{
    class Program
    {
        static double volume(double radius)
        {
            double volsp, pi;
            pi = 3.14;
            volsp = 4 / 3 * pi * radius * radius * radius * radius;
            Console.WriteLine("volume of sphere is" +volsp);
            return volsp;
        }
        static double volume(double r, double height)
        {
            double vol, pi;
            pi = 3.14;
            vol = pi * r * r * height;
            Console.WriteLine("volume of cylinder is" +vol);
            return vol;
        }
        static double volume(double length, double width, double h)
        {
            double volrp;
            volrp = length * width * h;
            Console.WriteLine("Volume of rectangular prism is" +volrp);
            return volrp;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("select");
            Console.WriteLine("1 for volume of sphere");
            Console.WriteLine("2 for volume of cylinder");
            Console.WriteLine("3 for volume of rectangular prism");
            string x = Console.ReadLine();
            int value = int.Parse(x);
            if (value == 1)
            {
                Console.WriteLine("Enter radius of sphere");
                string y = Console.ReadLine();
                double rad = double.Parse(y);
                volume(rad);
            }
            else if (value == 2)
            {
                Console.WriteLine("Enter radius and height of cylinder");
                String z = Console.ReadLine();
                double r = double.Parse(z);
                String m = Console.ReadLine();
                double h = double.Parse(m);
                volume(r,h);
            }
            else if (value == 3)
            {
                Console.WriteLine("Enter length,width and height of rectangular sphere");
                string n = Console.ReadLine();
                double l = double.Parse(n);
                string o = Console.ReadLine();
                double w = double.Parse(o);
                string p = Console.ReadLine();
                double hg = double.Parse(p);
                volume(l, w, hg);
            }

        }
    }
}
